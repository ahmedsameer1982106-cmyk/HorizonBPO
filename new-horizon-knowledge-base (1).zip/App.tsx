
import React, { useState, useEffect, useMemo } from 'react';
import { 
  UserRole, Project, User, KBArticle, ChatMessage, SystemNotification, NotificationReadLog
} from './types';
import { MOCK_PROJECTS, MOCK_USERS } from './constants';
import { askKnowledgeBase } from './geminiService';

const Toast: React.FC<{ message: string; visible: boolean; type?: 'success' | 'error' }> = ({ message, visible, type = 'success' }) => (
  <div className={`fixed bottom-8 left-1/2 -translate-x-1/2 z-[9999] transition-all duration-500 ${visible ? 'translate-y-0 opacity-100' : 'translate-y-12 opacity-0 pointer-events-none'}`}>
    <div className={`px-6 py-3 rounded-xl shadow-2xl flex items-center gap-3 font-bold text-sm text-white ${type === 'success' ? 'bg-indigo-600' : 'bg-red-500'}`}>
      <i className={`fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}`}></i>
      {message}
    </div>
  </div>
);

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [usersState, setUsersState] = useState<User[]>(() => JSON.parse(localStorage.getItem('h-u-final') || JSON.stringify(MOCK_USERS)));
  const [projectsState, setProjectsState] = useState<Project[]>(() => JSON.parse(localStorage.getItem('h-p-final') || JSON.stringify(MOCK_PROJECTS)));
  const [notifications, setNotifications] = useState<SystemNotification[]>(() => JSON.parse(localStorage.getItem('h-n-final') || '[]'));
  const [readLogs, setReadLogs] = useState<NotificationReadLog[]>(() => JSON.parse(localStorage.getItem('h-l-final') || '[]'));

  const [authStep, setAuthStep] = useState<'login' | 'force-change'>('login');
  const [pendingUser, setPendingUser] = useState<User | null>(null);

  const [activeProjectId, setActiveProjectId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArticle, setSelectedArticle] = useState<KBArticle | null>(null);
  const [modals, setModals] = useState({ create: false, audit: false, broadcast: false, projectMgr: false, accountMgr: false });
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [chat, setChat] = useState({ open: false, messages: [] as ChatMessage[], input: '', typing: false });
  const [toast, setToast] = useState({ msg: '', show: false, type: 'success' as 'success' | 'error' });
  const [forms, setForms] = useState({ article: { title: '', cat: '', tags: '', content: '' }, broadcast: { title: '', content: '' } });

  useEffect(() => {
    localStorage.setItem('h-u-final', JSON.stringify(usersState));
    localStorage.setItem('h-p-final', JSON.stringify(projectsState));
    localStorage.setItem('h-n-final', JSON.stringify(notifications));
    localStorage.setItem('h-l-final', JSON.stringify(readLogs));
  }, [usersState, projectsState, notifications, readLogs]);

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, show: true, type });
    setTimeout(() => setToast(p => ({ ...p, show: false })), 3000);
  };

  const visibleProjects = useMemo(() => 
    !currentUser ? [] : (currentUser.role === UserRole.ADMIN ? projectsState : projectsState.filter(p => currentUser.assignedProjectIds.includes(p.id)))
  , [projectsState, currentUser]);

  const activeProject = useMemo(() => 
    visibleProjects.find(p => p.id === activeProjectId) || visibleProjects[0]
  , [activeProjectId, visibleProjects]);

  const pendingAlert = useMemo(() => 
    !currentUser ? null : notifications.find(n => !readLogs.some(l => l.notificationId === n.id && l.userId === currentUser.id))
  , [notifications, readLogs, currentUser]);

  const handleAction = {
    login: (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const email = formData.get('email') as string;
      const pass = formData.get('pass') as string;
      const user = usersState.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === pass);
      
      if (user) { 
        if (user.firstLogin) {
          setPendingUser(user);
          setAuthStep('force-change');
          showToast("Identity verified. Mandatory update required.");
        } else {
          setCurrentUser(user); 
          showToast(`Session established: ${user.name}`); 
        }
      }
      else { showToast("Authentication failed", "error"); }
    },
    handlePasswordUpdate: (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const newPass = formData.get('newPass') as string;
      const confirmPass = formData.get('confirmPass') as string;

      if (newPass.length < 8) return showToast("Requirement: Min. 8 characters.", "error");
      if (newPass !== confirmPass) return showToast("Mismatch: Keys must be identical.", "error");

      if (pendingUser) {
        const updatedUser = { ...pendingUser, password: newPass, firstLogin: false };
        setUsersState(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
        setCurrentUser(updatedUser);
        setAuthStep('login');
        setPendingUser(null);
        showToast("Access key initialized. Welcome.");
      }
    },
    saveProject: (e: React.FormEvent) => {
      e.preventDefault();
      if (!editingProject) return;
      if (editingProject.id) {
        setProjectsState(p => p.map(x => x.id === editingProject.id ? editingProject : x));
      } else {
        const newP = { ...editingProject, id: `p-${Date.now()}`, kbArticles: [] };
        setProjectsState(p => [...p, newP]);
      }
      setEditingProject(null);
      showToast("Infrastructure silo synchronized");
    },
    saveUser: (e: React.FormEvent) => {
      e.preventDefault();
      if (!editingUser) return;
      if (editingUser.id) {
        setUsersState(u => u.map(x => x.id === editingUser.id ? editingUser : x));
      } else {
        setUsersState(u => [...u, { ...editingUser, id: `u-${Date.now()}`, firstLogin: true }]);
      }
      setEditingUser(null);
      showToast("Access matrix revised");
    },
    broadcast: (e: React.FormEvent) => {
      e.preventDefault();
      const n: SystemNotification = { 
        id: `n-${Date.now()}`, 
        ...forms.broadcast, 
        timestamp: new Date().toISOString(), 
        authorName: currentUser?.name || 'Command' 
      };
      setNotifications(p => [n, ...p]);
      setModals(p => ({ ...p, broadcast: false }));
      setForms(p => ({ ...p, broadcast: { title: '', content: '' } }));
      showToast("System broadcast dispatched");
    },
    saveArticle: (e: React.FormEvent) => {
      e.preventDefault();
      if (!activeProject) return;
      const art = { 
        id: selectedArticle?.id || `a-${Date.now()}`, 
        title: forms.article.title, 
        content: forms.article.content, 
        category: forms.article.cat || 'General', 
        lastUpdated: new Date().toISOString().split('T')[0],
        tags: forms.article.tags.split(',').map(t => t.trim())
      };
      setProjectsState(p => p.map(x => x.id === activeProject.id ? { 
        ...x, 
        kbArticles: selectedArticle ? x.kbArticles.map(a => a.id === selectedArticle.id ? art : a) : [art, ...x.kbArticles] 
      } : x));
      setModals(p => ({ ...p, create: false }));
      setSelectedArticle(null);
      showToast("Operational protocol published");
    },
    markRead: (id: string) => {
      if (!currentUser) return;
      setReadLogs(prev => [{ 
        notificationId: id, 
        userId: currentUser.id, 
        userName: currentUser.name, 
        readAt: new Date().toLocaleString() 
      }, ...prev]);
      showToast("Acknowledgement logged in ledger");
    }
  };

  const handleChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chat.input.trim() || chat.typing || !activeProject) return;
    const m: ChatMessage = { role: 'user', content: chat.input, timestamp: new Date() };
    setChat(p => ({ ...p, messages: [...p.messages, m], input: '', typing: true }));
    try {
      const res = await askKnowledgeBase(chat.input, activeProject, chat.messages.map(x => ({ role: x.role, content: x.content })));
      setChat(p => ({ ...p, messages: [...p.messages, { role: 'assistant', content: res, timestamp: new Date() }], typing: false }));
    } catch { showToast("AI engine offline", "error"); setChat(p => ({ ...p, typing: false })); }
  };

  if (!currentUser) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 font-sans">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-[3rem] p-12 text-center shadow-2xl animate-in fade-in zoom-in duration-700">
        <div className="w-20 h-20 bg-indigo-600 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-indigo-500/20">
          <i className={`fas ${authStep === 'login' ? 'fa-shield-halved' : 'fa-key-skeleton'} text-3xl text-white`}></i>
        </div>
        
        {authStep === 'login' ? (
          <>
            <h1 className="text-3xl font-black text-white mb-2 tracking-tighter">Horizon Hub</h1>
            <p className="text-slate-500 text-xs mb-10 font-bold uppercase tracking-widest">Operator Authorization</p>
            <form onSubmit={handleAction.login} className="space-y-4 text-left">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-4">Identifier</label>
                <input name="email" required type="email" placeholder="Email Address" className="w-full bg-slate-800 border border-slate-700 rounded-2xl p-4 text-white outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-4">Access Key</label>
                <input name="pass" required type="password" placeholder="Password" className="w-full bg-slate-800 border border-slate-700 rounded-2xl p-4 text-white outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <button type="submit" className="w-full bg-indigo-600 text-white font-black py-4 rounded-2xl hover:bg-indigo-700 transition-all shadow-lg mt-4">Authorize Access</button>
            </form>
            <div className="mt-10 pt-8 border-t border-slate-800 text-[10px] text-slate-500 font-bold uppercase tracking-widest text-center">
              Demo Credentials: ahmed.samir@horizonscope.com / password123
            </div>
          </>
        ) : (
          <div className="animate-in slide-in-from-right-12 duration-500">
            <h1 className="text-2xl font-black text-white mb-2 tracking-tighter">Security Protocol</h1>
            <p className="text-amber-500 text-[10px] mb-8 font-black uppercase tracking-widest">Mandatory Key Initialization</p>
            <form onSubmit={handleAction.handlePasswordUpdate} className="space-y-4 text-left">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-4">New Access Key</label>
                <input name="newPass" required type="password" placeholder="Min. 8 chars" className="w-full bg-slate-800 border border-slate-700 rounded-2xl p-4 text-white outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-4">Confirm New Key</label>
                <input name="confirmPass" required type="password" placeholder="Repeat password" className="w-full bg-slate-800 border border-slate-700 rounded-2xl p-4 text-white outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <button type="submit" className="w-full bg-amber-500 text-white font-black py-4 rounded-2xl hover:bg-amber-600 transition-all shadow-lg mt-4 uppercase text-xs tracking-widest">Initialize Identity</button>
              <button type="button" onClick={() => { setAuthStep('login'); setPendingUser(null); }} className="w-full text-slate-500 font-black text-[10px] uppercase tracking-widest py-3 hover:text-slate-300">Abort Session</button>
            </form>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen pl-80 bg-slate-50 text-slate-900 font-sans">
      <Toast message={toast.msg} visible={toast.show} type={toast.type} />
      
      <aside className="w-80 bg-slate-900 text-white h-screen fixed left-0 top-0 flex flex-col p-10 border-r border-slate-800 z-[100]">
        <div className="mb-12">
          <h1 className="text-3xl font-black tracking-tighter flex items-center gap-3"><i className="fas fa-tower-broadcast text-indigo-500"></i> Horizon</h1>
        </div>
        <nav className="flex-1 space-y-4 overflow-y-auto custom-scrollbar">
          <p className="text-[10px] uppercase font-black text-slate-500 tracking-widest mb-2">Clearance Matrix</p>
          {visibleProjects.map(p => (
            <button key={p.id} onClick={() => setActiveProjectId(p.id)} className={`w-full text-left p-4 rounded-2xl text-sm font-bold truncate transition-all ${activeProjectId === p.id ? 'bg-indigo-600 shadow-xl' : 'hover:bg-slate-800'}`}>{p.name}</button>
          ))}
          {currentUser.role === UserRole.ADMIN && (
            <div className="pt-8 space-y-2 border-t border-slate-800">
               <p className="text-[10px] uppercase font-black text-slate-500 mb-4">Command Center</p>
               <button onClick={() => setModals(m => ({ ...m, projectMgr: true }))} className="w-full text-left p-4 rounded-xl text-sm font-bold hover:bg-slate-800 transition-all flex items-center gap-3"><i className="fas fa-layer-group text-indigo-400 w-5"></i> Infrastructure</button>
               <button onClick={() => setModals(m => ({ ...m, accountMgr: true }))} className="w-full text-left p-4 rounded-xl text-sm font-bold hover:bg-slate-800 transition-all flex items-center gap-3"><i className="fas fa-users-gear text-indigo-400 w-5"></i> Staffing</button>
               <button onClick={() => setModals(m => ({ ...m, audit: true }))} className="w-full text-left p-4 rounded-xl text-sm font-bold hover:bg-slate-800 transition-all flex items-center gap-3"><i className="fas fa-file-signature text-indigo-400 w-5"></i> Compliance Ledger</button>
            </div>
          )}
        </nav>
        <div className="mt-auto pt-8 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-4">
             <div className="w-10 h-10 rounded-xl bg-indigo-500 flex items-center justify-center font-black text-sm shadow-inner">{currentUser.name.charAt(0)}</div>
             <div><p className="text-sm font-black leading-none truncate w-32">{currentUser.name}</p><p className="text-[9px] text-slate-500 font-bold uppercase mt-1 tracking-widest">{currentUser.role}</p></div>
          </div>
          <button onClick={() => setCurrentUser(null)} className="text-slate-500 hover:text-red-400 p-2"><i className="fas fa-power-off"></i></button>
        </div>
      </aside>

      <main className="p-16 max-w-7xl mx-auto">
        {activeProject ? (
          <>
            <header className="flex justify-between items-end mb-16 animate-in fade-in slide-in-from-top-6">
              <div className="max-w-2xl">
                <span className="text-[10px] font-black bg-indigo-600 text-white px-3 py-1 rounded-lg tracking-[0.2em] uppercase mb-4 inline-block">Authorized Silo</span>
                <h2 className="text-5xl font-black tracking-tighter mb-4">{activeProject.name}</h2>
                <p className="text-slate-500 text-lg font-medium leading-relaxed">{activeProject.description}</p>
              </div>
              <div className="flex gap-4">
                {currentUser.role !== UserRole.AGENT && <button onClick={() => setModals(m => ({ ...m, broadcast: true }))} className="px-8 py-4 bg-amber-500 text-white rounded-[1.5rem] font-black text-xs shadow-xl shadow-amber-900/20">Broadcast</button>}
                {currentUser.role !== UserRole.AGENT && <button onClick={() => { setSelectedArticle(null); setForms(f => ({ ...f, article: { title: '', cat: activeProject.categories[0] || 'General', tags: '', content: '' } })); setModals(m => ({ ...m, create: true })); }} className="px-8 py-4 bg-indigo-600 text-white rounded-[1.5rem] font-black text-xs shadow-xl shadow-indigo-900/40">New Protocol</button>}
              </div>
            </header>

            <div className="mb-16 relative max-w-3xl">
               <i className="fas fa-search absolute left-8 top-1/2 -translate-y-1/2 text-slate-400 text-lg"></i>
               <input type="text" placeholder="Probe operational silos..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full bg-white border border-slate-200 rounded-[2.5rem] py-6 pl-20 pr-8 text-lg outline-none shadow-sm focus:ring-4 focus:ring-indigo-500/10 transition-all" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 pb-40">
              {activeProject.kbArticles.filter(a => a.title.toLowerCase().includes(searchQuery.toLowerCase()) || a.content.toLowerCase().includes(searchQuery.toLowerCase())).map(article => (
                <div key={article.id} onClick={() => setSelectedArticle(article)} className="p-10 rounded-[3rem] bg-white border border-slate-100 hover:shadow-2xl transition-all cursor-pointer group flex flex-col h-full border-b-[6px] hover:border-indigo-500">
                  <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-6">{article.category}</span>
                  <h3 className="text-2xl font-black mb-6 leading-tight group-hover:text-indigo-600 transition-colors">{article.title}</h3>
                  <p className="text-sm text-slate-500 line-clamp-4 mb-10 flex-1 leading-relaxed">{article.content}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{article.lastUpdated}</span>
                    <i className="fas fa-arrow-right text-slate-200 group-hover:text-indigo-500 group-hover:translate-x-2 transition-all"></i>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="py-60 text-center text-slate-300 font-black text-4xl uppercase tracking-widest animate-pulse">Scanning for Clearance...</div>
        )}
      </main>

      {modals.audit && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-8 bg-slate-950/90 backdrop-blur-xl animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-5xl rounded-[4rem] shadow-3xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-12 border-b border-slate-800 flex justify-between items-center bg-slate-800/20">
              <div>
                <h2 className="text-4xl font-black text-white tracking-tighter">Compliance Ledger</h2>
                <p className="text-slate-500 text-lg mt-1 font-medium italic">Protocol acknowledgement records</p>
              </div>
              <button onClick={() => setModals(m => ({ ...m, audit: false }))} className="w-16 h-16 bg-slate-800 text-slate-400 rounded-2xl hover:text-white transition-all flex items-center justify-center"><i className="fas fa-times text-xl"></i></button>
            </div>
            <div className="p-12 overflow-y-auto custom-scrollbar flex-1">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-[10px] uppercase font-black text-slate-500 border-b border-slate-800 pb-8 tracking-[0.2em]">
                    <th className="pb-8 px-6">Operator</th>
                    <th className="pb-8">Context Heading</th>
                    <th className="pb-8 text-right px-6">Auth Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/30">
                  {readLogs.map((l, i) => (
                    <tr key={i} className="hover:bg-slate-800/20 transition-colors">
                      <td className="py-8 px-6 font-black text-white text-lg">{l.userName}</td>
                      <td className="py-8 text-slate-400 text-sm font-medium">"{notifications.find(n => n.id === l.notificationId)?.title || 'Broadcast Event'}"</td>
                      <td className="py-8 text-right px-6 text-xs font-mono text-slate-500 tracking-tighter uppercase">{l.readAt}</td>
                    </tr>
                  ))}
                  {readLogs.length === 0 && (
                    <tr><td colSpan={3} className="py-32 text-center text-slate-600 font-black uppercase tracking-[0.5em]">No acknowledgement data detected</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {modals.projectMgr && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-8 bg-slate-950/90 backdrop-blur-xl animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-5xl rounded-[4rem] shadow-3xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-12 border-b border-slate-800 flex justify-between items-center bg-slate-800/20">
              <h2 className="text-4xl font-black text-white tracking-tighter">Infrastructure Silos</h2>
              <div className="flex gap-4">
                <button onClick={() => setEditingProject({ id: '', companyId: 'c1', name: '', description: '', categories: ['General'], kbArticles: [] })} className="px-8 py-4 bg-indigo-600 text-white rounded-2xl text-xs font-black shadow-lg">Provision New Silo</button>
                <button onClick={() => setModals(m => ({ ...m, projectMgr: false }))} className="w-14 h-14 bg-slate-800 text-slate-400 rounded-2xl flex items-center justify-center"><i className="fas fa-times"></i></button>
              </div>
            </div>
            <div className="p-12 overflow-y-auto custom-scrollbar flex-1">
              {projectsState.map(p => (
                <div key={p.id} className="flex items-center justify-between p-8 border-b border-slate-800/50 hover:bg-slate-800/20 transition-colors">
                  <div>
                    <p className="font-black text-white text-2xl tracking-tighter">{p.name}</p>
                    <p className="text-sm text-slate-500 mt-2 font-medium">{p.description}</p>
                  </div>
                  <div className="flex gap-8">
                    <button onClick={() => setEditingProject(p)} className="text-[10px] uppercase text-indigo-400 font-black tracking-widest hover:text-indigo-300">Configure</button>
                    <button onClick={() => { setProjectsState(xs => xs.filter(x => x.id !== p.id)); showToast("Infrastructure deprovisioned", "error"); }} className="text-[10px] uppercase text-red-500 font-black tracking-widest hover:text-red-400">Purge</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {editingProject && (
        <div className="fixed inset-0 z-[700] flex items-center justify-center p-8 bg-slate-950/98 backdrop-blur-2xl animate-in zoom-in">
          <div className="bg-slate-900 border border-slate-700 p-16 rounded-[4rem] w-full max-w-xl shadow-3xl">
            <h3 className="text-3xl font-black text-white mb-10 tracking-tighter">Provisioning Setup</h3>
            <form onSubmit={handleAction.saveProject} className="space-y-6">
              <input required value={editingProject.name} onChange={e => setEditingProject({...editingProject, name: e.target.value})} className="w-full bg-slate-800 rounded-2xl p-6 text-white outline-none font-bold text-lg" placeholder="Entity Identity Name" />
              <textarea required value={editingProject.description} onChange={e => setEditingProject({...editingProject, description: e.target.value})} className="w-full bg-slate-800 rounded-2xl p-6 text-white outline-none resize-none h-40 leading-relaxed font-medium" placeholder="Operational Scope Description" />
              <input required value={editingProject.categories.join(', ')} onChange={e => setEditingProject({...editingProject, categories: e.target.value.split(',').map(c => c.trim())})} className="w-full bg-slate-800 rounded-2xl p-6 text-white outline-none font-mono text-sm border border-slate-700" placeholder="Operational Categories (Comma-separated)" />
              <div className="flex gap-6 pt-6">
                <button type="button" onClick={() => setEditingProject(null)} className="flex-1 text-slate-500 font-black uppercase text-xs tracking-widest">Abort</button>
                <button type="submit" className="flex-2 bg-indigo-600 text-white font-black py-5 rounded-[2rem] shadow-xl text-xs uppercase tracking-widest">Initialize Silo</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {modals.accountMgr && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-8 bg-slate-950/90 backdrop-blur-xl animate-in fade-in">
           <div className="bg-slate-900 border border-slate-800 w-full max-w-5xl rounded-[4rem] shadow-3xl overflow-hidden flex flex-col max-h-[85vh]">
              <div className="p-12 border-b border-slate-800 flex justify-between items-center bg-slate-800/20">
                 <h2 className="text-4xl font-black text-white tracking-tighter">Staff Authorization</h2>
                 <div className="flex gap-4">
                    <button onClick={() => setEditingUser({ id: '', name: '', email: '', role: UserRole.AGENT, assignedProjectIds: [], firstLogin: true, password: 'password123' })} className="px-8 py-4 bg-indigo-600 text-white rounded-2xl text-xs font-black shadow-lg">Authorize Staff</button>
                    <button onClick={() => setModals(m => ({ ...m, accountMgr: false }))} className="w-14 h-14 bg-slate-800 text-slate-400 rounded-2xl flex items-center justify-center"><i className="fas fa-times"></i></button>
                 </div>
              </div>
              <div className="p-12 overflow-y-auto custom-scrollbar flex-1">
                 {usersState.map(u => (
                   <div key={u.id} className="flex items-center justify-between p-8 border-b border-slate-800/50 hover:bg-slate-800/20 transition-colors">
                      <div className="flex items-center gap-6">
                        <div className="w-16 h-16 bg-slate-800 rounded-2xl flex items-center justify-center text-xl font-black text-indigo-400">{u.name.charAt(0)}</div>
                        <div>
                          <p className="font-black text-white text-2xl tracking-tighter">{u.name}</p>
                          <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mt-1">{u.role} Access Profile</p>
                        </div>
                      </div>
                      <div className="flex gap-8">
                         <button onClick={() => setEditingUser(u)} className="text-[10px] uppercase text-indigo-400 font-black tracking-widest">Matrix Control</button>
                         <button onClick={() => { if(u.id !== currentUser?.id) setUsersState(xs => xs.filter(x => x.id !== u.id)); else showToast("Self-revoke blocked", "error"); }} className="text-[10px] uppercase text-red-500 font-black tracking-widest">Revoke Access</button>
                      </div>
                   </div>
                 ))}
              </div>
           </div>
        </div>
      )}

      {editingUser && (
        <div className="fixed inset-0 z-[700] flex items-center justify-center p-8 bg-slate-950/98 backdrop-blur-2xl animate-in zoom-in">
          <div className="bg-slate-900 border border-slate-700 p-16 rounded-[4rem] w-full max-w-xl shadow-3xl">
            <h3 className="text-3xl font-black text-white mb-10 tracking-tighter">Identity Provisions</h3>
            <form onSubmit={handleAction.saveUser} className="space-y-6">
              <input required value={editingUser.name} onChange={e => setEditingUser({...editingUser, name: e.target.value})} className="w-full bg-slate-800 rounded-2xl p-6 text-white outline-none font-bold text-lg" placeholder="Legal Name" />
              <input required value={editingUser.email} onChange={e => setEditingUser({...editingUser, email: e.target.value})} className="w-full bg-slate-800 rounded-2xl p-6 text-white outline-none font-medium" placeholder="Corporate Identifier" />
              <select value={editingUser.role} onChange={e => setEditingUser({...editingUser, role: e.target.value as UserRole})} className="w-full bg-slate-800 rounded-2xl p-6 text-white outline-none font-black text-xs uppercase tracking-widest border border-slate-700">
                <option value={UserRole.AGENT}>Agent Level</option>
                <option value={UserRole.SUPERVISOR}>Supervisor Level</option>
                <option value={UserRole.ADMIN}>Administrator Level</option>
              </select>
              <p className="text-[10px] uppercase font-black text-slate-500 tracking-[0.2em] mt-8 mb-4 ml-2">Clearance Authorization</p>
              <div className="max-h-48 overflow-y-auto bg-slate-950 p-6 rounded-[2.5rem] border border-slate-800 space-y-4 custom-scrollbar">
                {projectsState.map(p => (
                  <label key={p.id} className="flex items-center gap-4 text-xs font-bold text-slate-300 cursor-pointer hover:text-white transition-colors">
                    <input type="checkbox" checked={editingUser.assignedProjectIds.includes(p.id)} onChange={e => {
                      const ids = e.target.checked ? [...editingUser.assignedProjectIds, p.id] : editingUser.assignedProjectIds.filter(x => x !== p.id);
                      setEditingUser({...editingUser, assignedProjectIds: ids});
                    }} className="w-6 h-6 rounded-lg bg-slate-800 border-slate-700 accent-indigo-500" />
                    {p.name}
                  </label>
                ))}
              </div>
              <div className="flex gap-6 pt-8">
                <button type="button" onClick={() => setEditingUser(null)} className="flex-1 text-slate-500 font-black uppercase text-xs tracking-widest">Discard</button>
                <button type="submit" className="flex-2 bg-indigo-600 text-white font-black py-5 rounded-[2rem] shadow-xl text-xs uppercase tracking-widest">Authorize Operator</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {modals.create && (
        <div className="fixed inset-0 z-[600] flex items-center justify-center p-8 bg-slate-950/95 backdrop-blur-xl animate-in fade-in">
          <div className="bg-slate-900 border border-indigo-500/20 p-16 rounded-[4rem] w-full max-w-4xl shadow-3xl">
            <h3 className="text-4xl font-black text-white mb-10 tracking-tighter">Protocol Entry</h3>
            <form onSubmit={handleAction.saveArticle} className="space-y-8">
              <input required placeholder="Documentation Heading" value={forms.article.title} onChange={e => setForms({...forms, article: {...forms.article, title: e.target.value}})} className="w-full bg-slate-800 rounded-3xl p-8 text-white outline-none text-2xl font-black border border-slate-700 shadow-inner" />
              <div className="grid grid-cols-2 gap-8">
                <select value={forms.article.cat} onChange={e => setForms({...forms, article: {...forms.article, cat: e.target.value}})} className="w-full bg-slate-800 rounded-3xl p-6 text-white outline-none text-xs font-black uppercase tracking-widest border border-slate-700">
                  {activeProject?.categories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <input placeholder="Search Tags (e.g. cloud, security)" value={forms.article.tags} onChange={e => setForms({...forms, article: {...forms.article, tags: e.target.value}})} className="w-full bg-slate-800 rounded-3xl p-6 text-white outline-none text-sm font-medium border border-slate-700" />
              </div>
              <textarea required rows={10} placeholder="Draft precise operational protocols..." value={forms.article.content} onChange={e => setForms({...forms, article: {...forms.article, content: e.target.value}})} className="w-full bg-slate-800 rounded-[2.5rem] p-10 text-white outline-none resize-none leading-relaxed font-medium border border-slate-700 shadow-inner custom-scrollbar" />
              <div className="flex gap-8 pt-4">
                <button type="button" onClick={() => setModals(m => ({ ...m, create: false }))} className="flex-1 text-slate-500 font-black uppercase tracking-widest text-xs">Discard Draft</button>
                <button type="submit" className="flex-2 bg-indigo-600 text-white font-black py-8 rounded-[2.5rem] hover:bg-indigo-700 shadow-2xl uppercase tracking-widest text-sm">Publish to Active Silo</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {modals.broadcast && (
        <div className="fixed inset-0 z-[600] flex items-center justify-center p-8 bg-slate-950/95 backdrop-blur-xl animate-in fade-in">
          <div className="bg-slate-900 border border-amber-500/20 p-16 rounded-[4rem] w-full max-w-2xl shadow-3xl">
            <h2 className="text-4xl font-black text-white mb-10 tracking-tighter">Command Broadcast</h2>
            <form onSubmit={handleAction.broadcast} className="space-y-8">
              <input required placeholder="Alert Scope Heading" value={forms.broadcast.title} onChange={e => setForms({...forms, broadcast: {...forms.broadcast, title: e.target.value}})} className="w-full bg-slate-800 rounded-3xl p-8 text-white outline-none text-xl font-black border border-slate-700 shadow-inner" />
              <textarea required rows={6} placeholder="Operational Instructions..." value={forms.broadcast.content} onChange={e => setForms({...forms, broadcast: {...forms.broadcast, content: e.target.value}})} className="w-full bg-slate-800 rounded-3xl p-8 text-white outline-none resize-none leading-relaxed font-medium border border-slate-700 shadow-inner" />
              <div className="flex gap-8 pt-4">
                <button type="button" onClick={() => setModals(m => ({ ...m, broadcast: false }))} className="flex-1 text-slate-500 font-black uppercase tracking-widest text-xs">Abort Dispatch</button>
                <button type="submit" className="flex-2 bg-amber-500 text-white font-black py-8 rounded-[2.5rem] hover:bg-amber-600 transition-all shadow-2xl uppercase tracking-widest text-sm">Transmit to Operators</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {selectedArticle && !modals.create && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-8 bg-slate-950/90 backdrop-blur-2xl animate-in fade-in">
           <div className="w-full max-w-4xl bg-white rounded-[4rem] shadow-3xl overflow-hidden flex flex-col max-h-[85vh] border border-slate-200 animate-in zoom-in">
              <div className="p-16 border-b flex justify-between items-start bg-slate-50/50">
                 <div>
                    <span className="text-[10px] px-5 py-2 rounded-full bg-indigo-100 text-indigo-600 font-black uppercase tracking-widest mb-6 inline-block">{selectedArticle.category}</span>
                    <h2 className="text-4xl font-black tracking-tight leading-tight mb-4">{selectedArticle.title}</h2>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest"><i className="fas fa-clock-rotate-left mr-2"></i> Version History Sync: {selectedArticle.lastUpdated}</p>
                 </div>
                 <button onClick={() => setSelectedArticle(null)} className="w-16 h-16 bg-white border border-slate-200 rounded-2xl flex items-center justify-center text-slate-400 hover:text-red-500 transition-all shadow-sm"><i className="fas fa-times text-2xl"></i></button>
              </div>
              <div className="p-16 overflow-y-auto text-xl leading-relaxed text-slate-700 font-medium custom-scrollbar whitespace-pre-wrap flex-1">{selectedArticle.content}</div>
              <div className="p-12 bg-slate-50/80 flex gap-6">
                 {currentUser?.role !== UserRole.AGENT && (
                   <button onClick={() => { setForms(f => ({ ...f, article: { title: selectedArticle.title, cat: selectedArticle.category, tags: selectedArticle.tags.join(', '), content: selectedArticle.content } })); setModals(m => ({ ...m, create: true })); }} className="flex-1 py-8 bg-indigo-600 text-white font-black rounded-[2.5rem] hover:bg-indigo-700 shadow-2xl uppercase tracking-widest text-xs">Modify Protocol</button>
                 )}
                 <button onClick={() => setSelectedArticle(null)} className="flex-1 py-8 border border-slate-300 font-black rounded-[2.5rem] text-slate-600 uppercase tracking-widest text-xs hover:bg-white transition-colors">Acknowledge Context</button>
              </div>
           </div>
        </div>
      )}

      <div className="fixed bottom-12 right-12 z-[250] flex flex-col items-end gap-6">
        {chat.open && (
          <div className="w-[32rem] h-[750px] bg-slate-900 border border-slate-800 rounded-[3.5rem] shadow-3xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-12 duration-500 ring-2 ring-indigo-500/20">
            <div className="p-10 bg-indigo-600 text-white flex justify-between items-center shadow-lg">
              <div className="flex items-center gap-4"><i className="fas fa-robot text-2xl"></i><h3 className="font-black tracking-tighter text-2xl">Horizon AI</h3></div>
              <button onClick={() => setChat(p => ({ ...p, open: false }))} className="p-4 hover:bg-white/10 rounded-2xl transition-all"><i className="fas fa-times"></i></button>
            </div>
            <div className="flex-1 overflow-y-auto p-10 space-y-8 bg-slate-900/50 custom-scrollbar">
               {chat.messages.map((m, i) => (
                 <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                   <div className={`p-8 rounded-[2.5rem] text-sm leading-relaxed max-w-[90%] shadow-2xl ${m.role === 'user' ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-slate-800 text-slate-200 rounded-bl-none border border-slate-700/50'}`}>
                      {m.content}
                   </div>
                 </div>
               ))}
               {chat.typing && <div className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] animate-pulse ml-4 italic">Analyzing Knowledge Repositories...</div>}
            </div>
            <form onSubmit={handleChat} className="p-8 bg-slate-900 flex gap-4 border-t border-slate-800">
               <input value={chat.input} onChange={e => setChat(p => ({ ...p, input: e.target.value }))} placeholder="Engage system interface..." className="flex-1 bg-slate-800 rounded-[2rem] px-8 py-5 text-white outline-none border border-slate-700 shadow-inner placeholder-slate-600" />
               <button type="submit" disabled={chat.typing} className="w-16 h-16 bg-indigo-600 text-white rounded-[1.5rem] flex items-center justify-center shadow-2xl active:scale-90 transition-all hover:bg-indigo-500"><i className="fas fa-bolt-lightning"></i></button>
            </form>
          </div>
        )}
        <button onClick={() => setChat(p => ({ ...p, open: !p.open }))} className="w-24 h-24 bg-gradient-to-tr from-indigo-500 to-indigo-800 rounded-[2.5rem] shadow-2xl flex items-center justify-center text-white text-3xl transition-all hover:scale-110 active:scale-95 ring-[12px] ring-indigo-500/10">
          <i className={`fas ${chat.open ? 'fa-times' : 'fa-headset'}`}></i>
        </button>
      </div>

      {pendingAlert && (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center p-8 bg-slate-950/98 backdrop-blur-3xl animate-in fade-in duration-500">
          <div className="w-full max-w-xl bg-white rounded-[4rem] p-16 text-center shadow-3xl border-t-[14px] border-amber-500 animate-in zoom-in duration-700">
            <div className="w-28 h-28 bg-amber-500 rounded-[2.5rem] flex items-center justify-center mx-auto mb-12 text-white text-5xl shadow-2xl animate-bounce-subtle">
              <i className="fas fa-triangle-exclamation"></i>
            </div>
            <h2 className="text-4xl font-black mb-6 tracking-tighter text-slate-900">Emergency Protocol</h2>
            <div className="bg-slate-50 p-10 rounded-[2.5rem] text-left mb-12 border border-slate-200 shadow-inner">
              <p className="text-indigo-600 font-black text-[10px] uppercase tracking-[0.3em] mb-4">{pendingAlert.title}</p>
              <p className="text-slate-800 text-2xl font-bold italic leading-relaxed">"{pendingAlert.content}"</p>
              <p className="mt-10 text-[9px] font-black uppercase text-slate-400 tracking-widest">— Authorized Dispatch by {pendingAlert.authorName}</p>
            </div>
            <button onClick={() => handleAction.markRead(pendingAlert.id)} className="w-full py-8 bg-slate-900 text-white rounded-[2.5rem] font-black uppercase tracking-[0.3em] text-xs hover:bg-indigo-600 transition-all shadow-2xl">Acknowledge System Status</button>
          </div>
        </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
        .shadow-3xl { box-shadow: 0 60px 120px -25px rgba(0, 0, 0, 0.9); }
        body { overflow-x: hidden; scroll-behavior: smooth; }
        @keyframes bounce-subtle { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        .animate-bounce-subtle { animation: bounce-subtle 4s infinite ease-in-out; }
      `}</style>
    </div>
  );
};

export default App;
