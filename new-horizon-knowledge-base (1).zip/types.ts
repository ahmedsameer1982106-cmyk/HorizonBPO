
export enum UserRole {
  ADMIN = 'ADMIN',
  AGENT = 'AGENT',
  SUPERVISOR = 'SUPERVISOR'
}

export interface Company {
  id: string;
  name: string;
  industry: string;
  logo: string;
}

export interface Project {
  id: string;
  companyId: string;
  name: string;
  description: string;
  kbArticles: KBArticle[];
  categories: string[];
}

export interface KBArticle {
  id: string;
  title: string;
  content: string;
  category: string;
  lastUpdated: string;
  tags: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: UserRole;
  assignedProjectIds: string[];
  firstLogin?: boolean;
}

export interface SystemNotification {
  id: string;
  title: string;
  content: string;
  timestamp: string;
  authorName: string;
}

export interface NotificationReadLog {
  notificationId: string;
  userId: string;
  userName: string;
  readAt: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}
