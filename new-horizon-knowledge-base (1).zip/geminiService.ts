
import { GoogleGenAI } from "@google/genai";
import { Project, KBArticle } from "./types";

// Always use named parameter for apiKey and obtain it from process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function askKnowledgeBase(
  question: string,
  currentProject: Project,
  history: { role: string; content: string }[]
): Promise<string> {
  const context = currentProject.kbArticles
    .map(a => `[Article: ${a.title}] ${a.content}`)
    .join("\n\n");

  const systemInstruction = `
    You are an expert call center assistant for the company "${currentProject.name}".
    Your goal is to provide accurate, concise, and helpful answers to staff based ONLY on the provided Knowledge Base context.
    
    Rules:
    1. If the answer is in the context, provide it clearly.
    2. If the answer is NOT in the context, say: "I'm sorry, I don't have specific information on that in the knowledge base for this project. Please escalate to your supervisor."
    3. Maintain a professional, supportive tone for the agent.
    4. Format your response with bullet points if helpful.
    
    Context:
    ${context}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history.map(h => ({ role: h.role === 'user' ? 'user' : 'model', parts: [{ text: h.content }] })),
        { role: 'user', parts: [{ text: question }] }
      ],
      config: {
        systemInstruction,
        temperature: 0.2, // Low temperature for accuracy
      },
    });

    // Access the .text property directly (not a method)
    return response.text || "No response generated.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error connecting to AI Assistant. Please check your network.";
  }
}
