
import { Company, Project, UserRole, User } from './types';

export const COMPANIES: Company[] = [
  { id: 'c1', name: 'TechFlow Solutions', industry: 'SaaS', logo: 'https://picsum.photos/seed/tech/100/100' },
  { id: 'c2', name: 'Global Retail Corp', industry: 'Retail', logo: 'https://picsum.photos/seed/retail/100/100' },
  { id: 'c3', name: 'Zenith Banking', industry: 'Finance', logo: 'https://picsum.photos/seed/bank/100/100' },
];

export const MOCK_PROJECTS: Project[] = [
  {
    id: 'p1',
    companyId: 'c1',
    name: 'Customer Success Tier 1',
    description: 'General support for TechFlow core application.',
    categories: ['Account Management', 'Billing', 'Technical Support', 'Security'],
    kbArticles: [
      {
        id: 'a1',
        title: 'Password Reset Protocol',
        category: 'Account Management',
        content: 'To reset a password, verify the user via two-factor authentication first. Then generate a 24-hour temporary link via the admin panel. Ensure the user is informed that the link expires.',
        lastUpdated: '2023-10-15',
        tags: ['security', 'account', 'password']
      },
      {
        id: 'a2',
        title: 'Refund Policy - Software',
        category: 'Billing',
        content: 'Refunds are granted if requested within 14 days of purchase and usage is below 10 hours. Escalation is required for prorated refunds.',
        lastUpdated: '2023-11-01',
        tags: ['billing', 'refund']
      }
    ]
  },
  {
    id: 'p2',
    companyId: 'c2',
    name: 'Order Fulfillment - US',
    description: 'Handling US-based retail inquiries and tracking.',
    categories: ['Logistics', 'Returns', 'Quality Control', 'Customer Service'],
    kbArticles: [
      {
        id: 'a3',
        title: 'Tracking Delayed Shipments',
        category: 'Logistics',
        content: 'If an order is delayed more than 3 business days, offer a $5 credit voucher. Use the ShipIt portal to verify the last known GPS coordinate of the courier.',
        lastUpdated: '2023-12-05',
        tags: ['shipping', 'delay', 'retail']
      }
    ]
  },
  {
    id: 'p3',
    companyId: 'c3',
    name: 'Wealth Management Desk',
    description: 'Specialized support for high-net-worth clients.',
    categories: ['Compliance', 'Internal Transfers', 'Wealth Advisory', 'Reporting'],
    kbArticles: [
      {
        id: 'a4',
        title: 'KYC Requirements for International Transfers',
        category: 'Compliance',
        content: 'All transfers over $50k require secondary verification of identity and source of funds. Form 1099-B must be mentioned for tax purposes.',
        lastUpdated: '2023-09-20',
        tags: ['compliance', 'finance', 'kyc']
      }
    ]
  }
];

export const MOCK_USERS: User[] = [
  {
    id: 'u-ahmed',
    name: 'Ahmed Samir',
    email: 'ahmed.samir@horizonscope.com',
    password: 'password123', // Initial password
    role: UserRole.ADMIN,
    assignedProjectIds: ['p1', 'p2', 'p3'],
    firstLogin: true
  },
  {
    id: 'u1',
    name: 'Alex Admin',
    email: 'alex@horizonscope.com',
    password: 'password123',
    role: UserRole.ADMIN,
    assignedProjectIds: ['p1', 'p2', 'p3']
  },
  {
    id: 'u2',
    name: 'Jamie Agent',
    email: 'jamie@horizonscope.com',
    password: 'password123',
    role: UserRole.AGENT,
    assignedProjectIds: ['p1']
  },
  {
    id: 'u3',
    name: 'Sam Supervisor',
    email: 'sam@horizonscope.com',
    password: 'password123',
    role: UserRole.SUPERVISOR,
    assignedProjectIds: ['p1', 'p2']
  }
];

export const CURRENT_USER: User = MOCK_USERS[0];
